package com.moshkou.md.models;


public class ContactModel {

    public String name;
    public String phone;
    public String image;

    public ContactModel(String name, String phone, String image) {
        this.name = name;
        this.phone = phone;
        this.image = image;
    }
}

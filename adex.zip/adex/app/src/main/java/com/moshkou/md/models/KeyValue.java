package com.moshkou.md.models;

public class KeyValue {
    public String key;
    public Object value;

    public KeyValue(String key, Object value) {
        this.key = key;
        this.value = value;
    }
}

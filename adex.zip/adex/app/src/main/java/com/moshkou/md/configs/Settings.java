package com.moshkou.md.configs;

import com.moshkou.md.models.UserModel;

public class Settings {

    public static UserModel user;

    public static String APP_PICTURE_DIRECTORY              = "";
    public static Enumerates.Connectivity CONNECTIVITY      = Enumerates.Connectivity.NO_CONNECTIVITY;

    public static double DEVICE_WIDTH                       = 0;
    public static double DEVICE_HEIGHT                      = 0;
    public static double DEVICE_DENSITY                     = 0;
}

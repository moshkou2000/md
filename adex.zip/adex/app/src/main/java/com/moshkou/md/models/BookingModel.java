package com.moshkou.md.models;


public class BookingModel {

    public String name;
    public String phone;
    public String image;

    public BookingModel(String name, String phone, String image) {
        this.name = name;
        this.phone = phone;
        this.image = image;
    }
}

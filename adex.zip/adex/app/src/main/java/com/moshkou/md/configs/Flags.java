package com.moshkou.md.configs;

public class Flags {
    public final static String LOGOUT                   = "LOGOUT";
    public final static String LOGIN                    = "LOGIN";
    public final static String NEW                      = "NEW";
    public final static String ORIGIN_DESTINATION       = "ORIGIN_DESTINATION";

}
